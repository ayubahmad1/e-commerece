require 'rails_helper'

RSpec.describe CommentsController do
  let(:comment1){build(:comment)}
  let(:product1){build(:product)}
  let(:user1){build(:user)}

  before do
    @product = product1
    @comment = comment1
  end
  # describe "GET /index" do
  #   pending "add some examples (or delete) #{__FILE__}"
  # end

  context 'Comments Controller Specs' do
    describe 'before_actions' do
      it { should use_before_action(:authenticate_user!) }
      it { should use_before_action(:set_product) }
      it { should use_before_action(:set_comment) }
    end

    describe 'after_actions' do
      it { should use_after_action(:verify_authorized) }
    end

    describe 'routes' do
      it { should route(:get, '/products/1/comments').to(action: :index, product_id: 1) }
      it { should route(:get, '/products/1/comments/new').to(action: :new, product_id: 1) }
      it { should route(:post, '/products/1/comments').to(action: :create, product_id: 1) }
      it { should route(:get, '/comments/1/edit').to(action: :edit, id: 1) }
      it { should route(:put, '/comments/1').to(action: :update, id: 1) }
      it { should route(:patch, '/comments/1').to(action: :update, id: 1) }
      it { should route(:delete, '/comments/1').to(action: :destroy, id: 1) }
    end


    describe 'GET #new' do
      login_user
      context 'Adding new comment to product' do
        let(:product) { create(:product)}
        let(:user) { create(:user)}
        before do
          get :new, params: {
            product_id: product.id
          }
        end
        it 'should have http status 200' do
          expect(response).to have_http_status(200)
        end
        it 'should respond with new' do
          expect(response).to render_template(:new)
        end
      end
    end

    describe 'POST #create' do
      login_user
      context 'Creating new product comment' do
        let(:product) { create(:product)}
        let(:comment) { create(:comment)}
        before do
          post :create, params: {
            comment: attributes_for(:comment),
            id: comment.id,
            product_id: product.id
          }
        end
        context 'with valid attributes' do
          it 'should assign a value to @comment' do
            expect(assigns(:comment)).not_to eq nil
          end
        end
        # it 'should respond with show' do
        #     get :show, params: {
        #       id: product.id
        #     }
        #   expect(response).to render_template(:show)
        # end
      end
    end


  end

end
